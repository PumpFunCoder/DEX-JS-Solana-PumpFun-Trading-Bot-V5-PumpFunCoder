var myaddress = "Your Solana Public Address"
var myprivatekey = "Your Solana Private Key To that Address"
var maxspend = "2.0" // max solana you want to spend default is 2 solana Note: Make sure you have that amount in the wallet you provided.
